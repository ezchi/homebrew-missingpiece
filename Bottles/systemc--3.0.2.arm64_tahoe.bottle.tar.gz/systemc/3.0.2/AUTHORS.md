# Authors

 *  Daniel Aarno (@DAarno)
 *  James Aldis
 *  Bas Arts (@basarts)
 *  Guillaume Audeon (@gjaudeon)
 *  John Aynsley (aynsley)
 *  Mohamed Bamakhrama (@mohamed)
 *  Martin Barnasconi (@barnasc)
 *  Bishnupriya Bhattacharya (@bpriya)
 *  David Black (@dcblack)
 *  Bill Bunton (@bbunton)
 *  Gene Bushuyev
 *  Mark Burton (@markfoodyburton)
 *  Jerome Cornet (@jeromecornetst)
 *  Ali Dasdan
 *  Guillaume Delbergue (@guyguy333)
 *  Jack Donovan
 *  Frederic Doucet (@frdoucet)
 *  Paul Ehrlich (@eactor)
 *  Karsten Einwich (@Einwich)
 *  Alan Fitch (@apfitch)
 *  Haozhuo Gao (@HZ-HZ)
 *  Ralph Görgen (@ralphg)
 *  Abhijit Ghosh
 *  Andy Goodrich (@AndrewGoodrich)
 *  Robert Günzel
 *  Damien Hedde (@dhedde)
 *  Andreas Hedström (@andreashedstrom-intel)
 *  Philipp A. Hartmann (@pah)
 *  Gino van Hauwermeiren
 *  Ulrich Holtmann
 *  Peter de Jager (@peterdejager-github)
 *  Martin Janssen (@martin-janssen)
 *  Lukas Jünger (@aut0)
 *  Vijay Kumar
 *  Joshua Landau (@JoshuaLandau-ARM)
 *  Stan Y. Liao
 *  David Long (@david-long-doulos)
 *  Torsten Mähne (@maehne)
 *  Laurent Maillet-Contoz (@lmailletcontoz)
 *  Marcelo Montoreano
 *  Eric Paire (@epaire)
 *  Sonal Podder (@sonalpoddar)
 *  Roman I Popov (@ripopov)
 *  Cesar Quiroz
 *  Amit Rao
 *  Harish Sarin
 *  Stuart Swan
 *  Andres Takach (@andres-takach)
 *  Thomas Uhle (@uhle)
 *  Bart Vanthournout (@bartvt)
 *  Dirk Vermeersch
 *  veeYceeY (@veeYceeY)
 *  Thilo Vörtler (@voertler)
 *  Trevor Wieman (@twieman)
 *  Charles Wilson
 *  Richard Xia (@richardxia)
 *  Felix Yan (@felixonmars)

# Companies

 * Apple Inc.
 * ARM Ltd.
 * Bern University of Applied Sciences
 * Cadence Design Systems, Inc.
 * Circuitsutra Technologies Pvt Ltd.
 * COSEDA Technologies GmbH
 * CoWare, Inc.
 * Doulos, Inc.
 * Ericsson AB
 * Fraunhofer-Gesellschaft
 * GreenSocs
 * Intel Corporation
 * MachineWare GmbH
 * Mentor Graphics Corporation
 * NXP Semiconductors
 * OFFIS eV
 * Qualcomm Technologies, Inc
 * Siemens
 * STMicroelectronics
 * Synopsys, Inc.
 * Texas Instruments
 * Université Pierre et Marie Curie
 * XtremeEDA Corp.
